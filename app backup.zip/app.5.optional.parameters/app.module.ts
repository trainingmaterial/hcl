import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app-main.component';
import { ShowHeroes } from './heroes.component';
import { ShowHero } from './hero.component';
import { HeroServices } from './hero.service';
import { EditHero } from './hero.edit';
 
@NgModule({
  declarations: [AppComponent,ShowHeroes,ShowHero, EditHero],
  imports: [BrowserModule, FormsModule, RouterModule.forRoot([
    {path:"", component:ShowHeroes},
    {path:"hero/:id", component:ShowHero, children : [
      { path : "edit/:val", component:EditHero},
      { path : "edit", component:EditHero}
    ]},
  ])],
  providers: [HeroServices], 
  bootstrap: [AppComponent]
})
export class AppModule { }
