import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";

@Component({
    template : `
    <h1>Edit Hero : Arg is {{ val }}</h1>
    <h1>Optional Parameters intelligence :  {{intel}}</h1>
    <h1>Optional Parameters race :  {{race}}</h1>
    `
})
export class EditHero implements OnInit{
    val;
    intel;
    race;

    constructor(private ar:ActivatedRoute){}
    ngOnInit() {
        this.val = this.ar.snapshot.params['val'];
        // console.log(this.ar.params);
        this.intel = this.ar.snapshot.params['intelligence'];
        this.race = this.ar.snapshot.params['race'];

        this.ar.params.subscribe( rparam => {
            this.val = rparam['val']
            this.intel = rparam['intelligence']
            this.race = rparam['race']
        } )
    };


}