import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app-main.component';
import { ShowHeroes } from './showheroes.component';
import { HeroServices } from './hero.service';
import { HeroPipe } from './herofilter.pipe';
import { ShowHero } from './showhero.component';
import { resolve } from 'url';
import { HeroResolverService } from './heroresolver.service';
 
@NgModule({
  declarations: [AppComponent, ShowHeroes, ShowHero, HeroPipe ],
  imports: [BrowserModule, FormsModule, RouterModule.forRoot([
    {
      path:"", component:ShowHeroes, 
      data : {apptitle : "Heroes Application"},
      resolve : { herodata : HeroResolverService }
  },
    {
      path:"hero", 
      component:ShowHero,
      resolve : { herodata : HeroResolverService }      
    }
  ])],
  providers: [HeroServices, HeroResolverService], 
  bootstrap: [AppComponent]
})
export class AppModule { }
