import { Component, OnInit } from '@angular/core';
import { HeroServices } from './hero.service';
import { ActivatedRoute } from '@angular/router';

@Component({
    template:`
    <a [routerLink]="['']">Back to List</a> 
    <h2> Show Details </h2>
    <h3>selected hero is : {{ selhero }} | {{ heroes[selhero-1].name }}</h3>
    <img width="100" src="{{ heroes[selhero-1].image.url }}" alt="{{ heroes[selhero-1].name }}">
    <hr>
    `
  })
  export class ShowHero implements OnInit{
    selhero = 0;
    filterherodata = '';
    heroes = []; 
    constructor(private hd:HeroServices, private ar:ActivatedRoute ){};
    ngOnInit() {
      this.selhero = this.ar.snapshot.queryParams['hid'];
      this.filterherodata = this.ar.snapshot.queryParams['filterdata'];
      this.heroes = this.ar.snapshot.data['herodata'].heroes;
      // this.heroes = this.hd.getData().heroes; 
    }; 
  } 