import { Component, OnInit } from '@angular/core';
import { HeroServices } from './hero.service';
import { ActivatedRoute } from '@angular/router';

@Component({
    template:`
    <input type="range" [(ngModel)]="params">
    <a [routerLink]="['']">Back to List</a>
    <a [routerLink]="['edit', params]">Edit</a>
    <h2> Show Details </h2>
    <h3>{{ selhero }}{{ heroes[selhero-1].name }}</h3>
    <img width="100" src="{{ heroes[selhero-1].image.url }}" alt="{{ heroes[selhero-1].name }}">
    <hr>
    <router-outlet></router-outlet>
    `
  })
  export class ShowHero implements OnInit{
    params = 0;
    heroes = [];
    selhero = 0;
    constructor(private hd:HeroServices, private ar:ActivatedRoute ){ 
      this.heroes = hd.getData().heroes;
    };
    ngOnInit() {
      this.selhero = this.ar.snapshot.params['id'];
      console.log(this.heroes);
    };
  } 