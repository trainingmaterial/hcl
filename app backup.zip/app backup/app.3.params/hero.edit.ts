import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";

@Component({
    template : `
    <h1>Edit Hero : Arg is {{ val }}</h1>
    `
})
export class EditHero implements OnInit{
    val;
    constructor(private ar:ActivatedRoute){}
    ngOnInit() {
        this.val = this.ar.snapshot.params['val'];
        this.ar.params.subscribe( rparam => this.val = rparam['val'] )
    };


}