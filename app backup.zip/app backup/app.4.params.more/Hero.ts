export class Hero{
    id
    name
    powerstats = {
        intelligence : "",
        strength : "",
        speed : "",
        durability : "",
        power : "",
        combat : ""
    }
    biography = {
        "full-name" : "",
        "place-of-birth" : "",
        publisher : "",
        "release-date" : "",
        earning : "",
        budget :""
    }
    appearance = {
        gender : "",
        race : "",
        height : [],
        weight : [],
        "eye-color" : "",
        "hair-color" : ""
    }
    work = {
        occupation : "",
        base : ""
    }
    image = {
        url : ""
    }
}
