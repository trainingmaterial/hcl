import { NgModule } from "@angular/core";
import { MoviesShow } from "./movies.component";
import { MoviesEdit } from "./movies.edit.component";
import { RouterModule } from "@angular/router";


const movieRoutes = [
    { path : "movies", component: MoviesShow },
    { path : "movies/:id", component: MoviesEdit }
  ]

@NgModule({
    declarations:[MoviesShow, MoviesEdit],
    imports:[ RouterModule.forChild(movieRoutes)],
    exports:[MoviesShow, MoviesEdit]
})
export class MoviesModule{

}


