import { Component } from '@angular/core';
//====================================================

@Component({
  selector: 'app-root',
  template : `
    <h1>Welcome Component</h1>
  `
})
export class WelcomeComponent {
  title = 'step6routing';
}
//====================================================