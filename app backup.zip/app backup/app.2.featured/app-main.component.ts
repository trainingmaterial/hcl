import { Component } from '@angular/core';
//====================================================

@Component({
  selector: 'app-root',
  template : `
  <h1>Routing 101</h1>
  <hr>
  <div class="navbar navbar-expand-lg navbar-dark bg-dark">
  <ul class="navbar-nav ">
    <li class="nav-item"><a class="nav-link" [routerLink]="['']">Home</a></li>
    <li class="nav-item"><a class="nav-link" [routerLink]="['hero']">Heroes</a></li>
    <li class="nav-item"><a class="nav-link" [routerLink]="['hero','heroid']">Edit Hero</a></li>
    <li class="nav-item"><a class="nav-link" [routerLink]="['movies']">Show Movies</a></li>
    <li class="nav-item"><a class="nav-link" [routerLink]="['movies','movieid']">Edit Movie</a></li>
  </ul>
  <ul class="navbar-nav ml-auto">
    <li class="nav-item"><a class="nav-link" [routerLink]="['login']">Login</a></li>
  </ul>
</div>
  <router-outlet></router-outlet>
  `
})
export class HeroAppComponent {
  title = 'step6routing';
}
//====================================================