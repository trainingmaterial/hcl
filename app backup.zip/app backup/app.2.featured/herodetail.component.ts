import { Component } from '@angular/core';

@Component({
    selector:'app-herodetail',
    template:`
    <h2> Hero Detail </h2>
    `
})
export class HeroDetail{

}