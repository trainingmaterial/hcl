import { Component } from '@angular/core';

@Component({
    selector:'app-showmovies',
    template:`
    <h2> Edit Movies </h2>
    `
  })
  export class MoviesEdit{
    
  }