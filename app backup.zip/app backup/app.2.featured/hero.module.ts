import { NgModule } from "@angular/core";

import { HeroList } from "../app.1/herolist.component";
import { HeroDetail } from "./herodetail.component";
import { HeroAdd } from "./heroadd.component";
import { RouterModule } from "@angular/router";

const heroRoutes = [
    { path : "hero", component: HeroList },
    { path : "hero/:id", component: HeroDetail }
  ]

@NgModule({
    declarations:[HeroList,HeroDetail,HeroAdd],
    imports:[ RouterModule.forChild(heroRoutes)],
    exports:[HeroList,HeroDetail,HeroAdd]
})
export class HeroModule{

}


