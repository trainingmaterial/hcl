import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HeroAppComponent} from './app-main.component';
import { LoginApp } from './login.component';
import { MoviesModule } from './movie.module';
import { HeroModule } from './hero.module';
import { WelcomeComponent } from './welcome.component';


@NgModule({
  declarations: [
    HeroAppComponent, LoginApp, WelcomeComponent
  ],
  imports: [
    BrowserModule, RouterModule.forRoot([
      { path:'', component:WelcomeComponent},
      { path:'login', component:LoginApp}
    ]),
    HeroModule,
    MoviesModule
  ],
  providers: [],
  bootstrap: [HeroAppComponent]
})
export class AppModule { }
