import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HeroAppComponent} from './app-main.component';
import { HeroList } from './herolist.component';
import { AddHero } from './addhero.component';
import { ShowMovies } from './movies.component';
import { LoginApp } from './login.component';

@NgModule({
  declarations: [
    HeroAppComponent, HeroList, AddHero, ShowMovies, LoginApp
  ],
  imports: [
    BrowserModule, RouterModule.forRoot([
      { path : "", component: LoginApp },
      { path : "list", component: HeroList },
      { path : "add", component: AddHero },
      { path : "movies", component: ShowMovies },
      { path : "**", redirectTo:"", pathMatch:"full" }
    ], { useHash : true } )
  ],
  providers: [],
  bootstrap: [HeroAppComponent]
})
export class AppModule { }
