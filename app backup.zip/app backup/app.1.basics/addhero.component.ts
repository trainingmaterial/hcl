import { Component } from '@angular/core';

@Component({
    selector:'app-addhero',
    template:`
    <h2> Add Hero </h2>
    `
  })
  export class AddHero{
    
  }