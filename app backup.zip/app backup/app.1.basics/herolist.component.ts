import { Component } from '@angular/core';

@Component({
    selector:'app-herolist',
    template:`
    <h2> Hero List </h2>
    `
})
export class HeroList{

}