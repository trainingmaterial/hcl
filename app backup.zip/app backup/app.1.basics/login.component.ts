import { Component } from '@angular/core';

@Component({
  selector:'app-login',
  template:`
  <h2> Login </h2>
  `
})
export class LoginApp{
  
}